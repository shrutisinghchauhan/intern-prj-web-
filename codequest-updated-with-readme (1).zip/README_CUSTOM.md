
# 📦 Custom Feature Implementation Summary (CodeQuest)

This document outlines all the features implemented and the corresponding file changes made in this project.

---

## ✅ 1. Google & Phone Authentication (Firebase)
- **Frontend**
  - `src/firebase.js` – Firebase config & initialization.
  - `src/components/Auth/Login.js` – Google & Phone login.
  - `src/components/Auth/Signup.js` – Google & Phone signup.
  - `src/App.js` – Firebase auth context integration.
- **Backend**
  - `routes/user.js`, `controller/userController.js` – New route to verify Firebase token.
  - Middleware to store/update user in DB after Firebase login.

---

## ✅ 2. Notification Feature
- **Frontend**
  - `src/components/Notifications/NotificationManager.js` – Enables/disables browser notifications.
  - Triggers for: Answer received, Upvote received.
- **Backend**
  - `socket.js`, `answerController.js`, `voteController.js` – Emit events to trigger notifications.

---

## ✅ 3. Forgot Password (Limited to Once Per Day)
- **Frontend**
  - `src/components/Auth/ForgotPassword.js` – Form with daily attempt warning.
  - `src/utils/passwordGenerator.js` – Uppercase + lowercase password generator (no digits/symbols).
- **Backend**
  - `routes/auth.js`, `controller/authController.js` – Route checks attempt history and sends new password.

---

## ✅ 4. Video Upload for Questions
- **Frontend**
  - `src/components/Questions/AskVideoQuestion.js` – Upload form, video length check (<2 min), size check (<50MB).
  - OTP verification modal (via email).
- **Backend**
  - `routes/questions.js`, `controller/questionController.js` – Video validation + OTP verification.
  - Middleware restricts upload time to 2 PM–7 PM only.

---

## ✅ 5. Reward System
- **Frontend**
  - `src/components/Profile/Points.js` – Show user points.
  - `src/components/Profile/TransferPoints.js` – Transfer UI (only if >10 points).
- **Backend**
  - `models/User.js`, `controllers/answerController.js`, `voteController.js` – Add, reduce, and transfer points.
  - Point logic:
    - +5: Answer submitted
    - +5: Answer gets 5 upvotes
    - -5: Answer removed / downvoted

---

## ✅ 6. Track User Login Info
- **Frontend**
  - Detects browser, OS, device type.
- **Backend**
  - `models/User.js` – New `loginHistory` array.
  - Tracks: IP, browser, OS, device.
  - Rules:
    - Chrome → Email OTP required.
    - Edge → No OTP.
    - Mobile → Access only between 10 AM–1 PM.

---

## ✅ 7. Subscription Plans & Payment
- **Frontend**
  - `src/components/Subscriptions/Plans.js` – Plan UI (Free, Bronze ₹100, Silver ₹300, Gold ₹1000).
  - Stripe integrated for payments.
- **Backend**
  - `routes/subscription.js`, `controllers/subscriptionController.js` – Handle plans, limits, invoices.
  - Time-based payment window: 10–11 AM IST only.
  - Question post limits enforced based on plan.

---

🎉 All features are now live in the updated project. This README_CUSTOM.md will help you or any collaborator understand the architecture and logic behind the feature additions.
